from django.apps import AppConfig


class SkolawebConfig(AppConfig):
    name = 'skolaweb'
