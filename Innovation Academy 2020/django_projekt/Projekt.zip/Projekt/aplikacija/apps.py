from django.apps import AppConfig


class AplikacijaConfig(AppConfig):
    name = 'aplikacija'
